#include <iostream>
#include <vector>
#include <glad/gl.h>
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include "linmath.h"

#include "shaders.h" // vertex and fragment shaders
#include "object.h"  // primitive shapes
#include "texture.h" // texture images

// camera parameters
float camera_radius = 5;     // radius of camera orbit
float camera_angle = -0.7f;  // camera angle on its orbit
float camera_height = 3;     // height of camera orbit
float camera_yaw = 0;        // horizontal camera angle
float camera_pitch = 0;      // vertical camera angle
float camera_speed = 0.005f; // nuanced camera speed
bool ortho_camera = false;   // perspective or orthographic camera type

// mouse parameters
bool mouse_button_down = false;    // mouse button status
double cursor_x = 0, cursor_y = 0; // cursor coordinates

static void error_callback(int error, const char* description)
{
    std::cout << "Error: " << description << std::endl;
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // check key presses or repeated key presses
    if (action != GLFW_PRESS && action != GLFW_REPEAT)
        return;

    // quit
    if (key == GLFW_KEY_ESCAPE)
        glfwSetWindowShouldClose(window, GLFW_TRUE);

    // move the camera forward
    if (key == GLFW_KEY_W)
    {
        camera_radius -= 0.2f;
        if (camera_radius < 1)
            camera_radius = 1;
    }

    // move the camera backward
    if (key == GLFW_KEY_S)
    {
        camera_radius += 0.2f;
        if (camera_radius > 8)
            camera_radius = 8;
    }

    // move the camera left
    if (key == GLFW_KEY_A)
        camera_angle -= 0.1f;

    // move the camera right
    if (key == GLFW_KEY_D)
        camera_angle += 0.1f;

    // move the camera upward
    if (key == GLFW_KEY_Q)
    {
        camera_height += 0.2f;
        if (camera_height > 8)
            camera_height = 8;
    }

    // move the camera downward
    if (key == GLFW_KEY_E)
    {
        camera_height -= 0.2f;
        if (camera_height < 0.2f)
            camera_height = 0.2f;
    }

    // toggle the perspective or orthographic camera type
    if (key == GLFW_KEY_C)
        ortho_camera = !ortho_camera;
}

static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if (button != GLFW_MOUSE_BUTTON_LEFT)
        return;

    // detect button pressing
    if (action == GLFW_PRESS)
    {
        mouse_button_down = true;

        // update cursor coordinates
        double xpos = 0, ypos = 0;
        glfwGetCursorPos(window, &xpos, &ypos);
        cursor_x = xpos;
        cursor_y = ypos;
    }

    // detect button releasing
    if (action == GLFW_RELEASE)
        mouse_button_down = false;
}

static void cursor_pos_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (mouse_button_down)
    {
        // drag the camera view
        camera_yaw -= float(xpos - cursor_x) * camera_speed;
        camera_pitch -= float(ypos - cursor_y) * camera_speed;

        // update cursor coordinates
        cursor_x = xpos;
        cursor_y = ypos;
    }
}

static void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    // adjust the nuanced camera speed
    camera_speed += (float)yoffset * 0.001f;
    if (camera_speed < 0.001f)
        camera_speed = 0.001f;
    if (camera_speed > 0.020f)
        camera_speed = 0.020f;
}

int main(void)
{
    glfwSetErrorCallback(error_callback);

    if (!glfwInit())
        exit(EXIT_FAILURE);

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(640, 480, "Simple example", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    // set key and mouse callbacks
    glfwSetKeyCallback(window, key_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetCursorPosCallback(window, cursor_pos_callback);
    glfwSetScrollCallback(window, scroll_callback);

    glfwMakeContextCurrent(window);
    gladLoadGL(glfwGetProcAddress);
    glfwSwapInterval(1);

    // create vertex and fragment shaders
    Shaders shaders;
    shaders.create();

    // create objects
    Object plane, cube, cylinder, torus;
    plane.create_plane(shaders);
    cube.create_cube(shaders);
    cylinder.create_cylinder(shaders);
    torus.create_torus(shaders);

    // load textures
    Texture desk, wood;
    desk.load("desk.jpg");
    wood.load("wood.jpg");

    while (!glfwWindowShouldClose(window))
    {
        // update the viewport size
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        glViewport(0, 0, width, height);

        // clear the window
        glClearColor(0.3f, 0.3f, 0.3f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);

        // enable transparent blending
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        // set the view matrix
        vec3 eye = {camera_radius * sinf(camera_angle), camera_height, camera_radius * cosf(camera_angle)};
        vec3 center = {0, 1, 0};
        vec3 up = {0, 1, 0};
        mat4x4 view_matrix;
        mat4x4_look_at(view_matrix, eye, center, up);

        // left-multiply the view matrix by the pitch matrix
        mat4x4 pitch_matrix;
        mat4x4_identity(pitch_matrix);
        mat4x4_rotate_X(pitch_matrix, pitch_matrix, camera_pitch);
        mat4x4_mul(view_matrix, pitch_matrix, view_matrix);

        // left-multiply the view matrix by the yaw matrix
        mat4x4 yaw_matrix;
        mat4x4_identity(yaw_matrix);
        mat4x4_rotate_Y(yaw_matrix, yaw_matrix, camera_yaw);
        mat4x4_mul(view_matrix, yaw_matrix, view_matrix);
        glUniformMatrix4fv(shaders.uniform("view_matrix"), 1, GL_FALSE, (const GLfloat*)view_matrix);

        // set the projection matrix
        float ratio = (float)width / height;
        mat4x4 proj_matrix;
        if (ortho_camera)
            mat4x4_ortho(proj_matrix, -3.0f * ratio, 3.0f * ratio, -3.0f, 3.0f, -100.0f, 100.0f);
        else mat4x4_perspective(proj_matrix, 1.0f, ratio, 0.1f, 100.0f);
        glUniformMatrix4fv(shaders.uniform("proj_matrix"), 1, GL_FALSE, (const GLfloat*)proj_matrix);

        // set default materials (ambient, diffuse, specular)
        glUniform1f(shaders.uniform("ka"), 0.2f);
        glUniform1f(shaders.uniform("kd"), 0.8f);
        glUniform1f(shaders.uniform("ks"), 5.0f);

        // draw the desk object
        glUniform1i(shaders.uniform("textured"), 1);
        glUniform1i(shaders.uniform("transparent"), 0);
        desk.bind();
        plane.draw(shaders, 0.0f, 0.0f, 0.0f, 5.0f, 5.0f, 5.0f);

        // draw the textured cube object
        glUniform1f(shaders.uniform("ks"), 0.0f);
        wood.bind();
        cube.draw(shaders, -1.0f, 1.0f, -0.4f, 0.2f, 1.0f, 0.2f);

        // draw the non-textured cube object
        glUniform1i(shaders.uniform("textured"), 0);
        cube.draw(shaders, -1.0f, 0.15f, +0.4f, 1.2f, 0.15f, 0.3f);

        // draw the tape object
        glUniform1f(shaders.uniform("ks"), 10.0f);
        glUniform3f(shaders.uniform("object_color"), 0.2f, 0.4f, 0.8f);
        torus.draw(shaders, -0.8f, 0.0f, 1.5f, 0.7f, 0.3f, 0.7f);

        // draw the transparent glass object without writing to depth buffer
        glUniform1i(shaders.uniform("transparent"), 1);
        glUniform3f(shaders.uniform("object_color"), 1.0f, 1.0f, 1.0f);
        glUniform1f(shaders.uniform("ks"), 10.0f);
        glDepthMask(GL_FALSE);
        cylinder.draw(shaders, 1.0f, 0.0f, 1.5f, 0.72f, 1.5f, 0.72f);
        cylinder.draw(shaders, 1.0f, 0.0f, 1.5f, 0.68f, 1.5f, 0.68f);
        glDepthMask(GL_TRUE);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);

    glfwTerminate();
    exit(EXIT_SUCCESS);
}
