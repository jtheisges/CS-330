#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

class Texture
{
public:
    Texture()
    {
        textureID = 0;
    }

    void load(const char* filename)
    {
        // load the image
        int width = 0, height = 0, components = 0;
        unsigned char* image = stbi_load(filename, &width, &height, &components, 3);

        // check for errors
        if (!image)
        {
            std::cout << "Error loading " << filename << std::endl;
            return;
        }
        std::cout << "Loading texture: " << filename << std::endl;

        // create a texture ID
        glGenTextures(1, &textureID);

        // set the image pixels
        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

        // use linear filtering with mipmapping
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

        // free the image
        stbi_image_free(image);
    }

    void bind()
    {
        // select this texture
        glBindTexture(GL_TEXTURE_2D, textureID);
    }

private:
    GLuint textureID;
};
