
const char* vertex_shader_text =
"#version 330\n"

// transformation matrices
"uniform mat4 model_matrix;\n"
"uniform mat4 view_matrix;\n"
"uniform mat4 proj_matrix;\n"

// vertex attributes
"in vec3 vertex_pos;\n"
"in vec3 vertex_normal;\n"
"in vec2 vertex_texcoord;\n"

// outputs for the fragment shader
"out vec3 fragment_pos;\n"
"out vec3 fragment_normal;\n"
"out vec2 fragment_texcoord;\n"

"void main()\n"
"{\n"
    // normal matrix is the inverse transpose of the modelview matrix
    "mat3 normal_matrix = inverse(transpose(mat3(view_matrix * model_matrix)));\n"

    // transform the vertex position
    "gl_Position = proj_matrix * view_matrix * model_matrix * vec4(vertex_pos, 1.0);\n"

    // position in eye space
    "fragment_pos = (view_matrix * model_matrix * vec4(vertex_pos, 1.0)).xyz;\n"

    // normal in eye space
    "fragment_normal = normalize(normal_matrix * vertex_normal);\n"

    // texture coordinates
    "fragment_texcoord = vertex_texcoord;\n"
"}\n";

const char* fragment_shader_text =
"#version 330\n"

// texture sampler
"uniform sampler2D sampler;\n"

// object states
"uniform bool textured;\n"
"uniform bool transparent;\n"
"uniform vec3 object_color;\n"

// object materials (ambient, diffuse, specular)
"uniform float ka;\n"
"uniform float kd;\n"
"uniform float ks;\n"

// inputs from the vertex shader
"in vec3 fragment_pos;\n"
"in vec3 fragment_normal;\n"
"in vec2 fragment_texcoord;\n"

// final fragment color
"out vec4 fColor;\n"

"float lighting(vec3 lightDir)\n"
"{\n"
    // ambient lighting
    "float light = ka;\n"

    // diffuse lighting
    "vec3 normal = normalize(fragment_normal);\n"
    "float diffuse = max(dot(lightDir, normal), 0.0);\n"
    "light += diffuse * kd;\n"

    // specular lighting
    "vec3 viewDir = normalize(fragment_pos);\n"
    "vec3 reflectedDir = reflect(viewDir, normal);\n"
    "float specular = max(dot(reflectedDir, lightDir), 0.0);\n"
    "light += pow(specular, 10.0) * ks;\n"

    "return light;\n"
"}\n"

"void main()\n"
"{\n"
    // colors and directions for 2 light sources
    "vec3 lightColor1 = vec3(0.9, 0.9, 1.0);\n"
    "vec3 lightColor2 = vec3(1.0, 0.8, 0.8);\n"
    "vec3 lightDir1 = normalize(vec3(-2, 1, -3));\n"
    "vec3 lightDir2 = normalize(vec3(+1, 2, +3));\n"

    // total light from the 2 light sources
    "vec3 light = lightColor1 * lighting(lightDir1) + lightColor2 * lighting(lightDir2);\n"

    // use object color by default
    "fColor = vec4(object_color, 1.0);\n"

    // for textured objects, apply the texture value
    "if (textured)\n"
        "fColor = texture(sampler, fragment_texcoord);\n"

    // for transparent objects, use a small alpha value
    "if (transparent)\n"
        "fColor.a = 0.2;\n"

    // combine color with lighting
    "fColor.rgb *= light;\n"
"}\n";

class Shaders
{
public:
    Shaders()
    {
        program = 0;
    }

    void create()
    {
        // create a vertex shader
        GLuint vertex_shader = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertex_shader, 1, &vertex_shader_text, NULL);
        glCompileShader(vertex_shader);

        // verify vertex compilation
        int success = 0;
        glGetShaderiv(vertex_shader, GL_COMPILE_STATUS, &success);
        if (!success)
        {
            char infoLog[1000];
            glGetShaderInfoLog(vertex_shader, 1000, NULL, infoLog);
            std::cout << "Vertex shader error:" << std::endl << infoLog << std::endl;
        }

        // create a fragment shader
        GLuint fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragment_shader, 1, &fragment_shader_text, NULL);
        glCompileShader(fragment_shader);
        glGetShaderiv(fragment_shader, GL_COMPILE_STATUS, &success);

        // verify fragment compilation
        if (!success)
        {
            char infoLog[1000];
            glGetShaderInfoLog(fragment_shader, sizeof(infoLog), NULL, infoLog);
            std::cout << "Fragment shader error:" << std::endl << infoLog << std::endl;
        }

        // create and link a program
        program = glCreateProgram();
        glAttachShader(program, vertex_shader);
        glAttachShader(program, fragment_shader);
        glLinkProgram(program);

        // verify program linking
        glGetProgramiv(program, GL_LINK_STATUS, &success);
        if (!success)
        {
            char infoLog[1000];
            glGetProgramInfoLog(program, sizeof(infoLog), NULL, infoLog);
            std::cout << "Shader linking error:" << std::endl << infoLog << std::endl;
        }

        glUseProgram(program);
    }

    GLint attrib(const char* name)
    {
        // look up the attribute location by its name
        return glGetAttribLocation(program, name);
    }

    GLint uniform(const char* name)
    {
        // look up the uniform location by its name
        return glGetUniformLocation(program, name);
    }

private:
    GLuint program;
};
