
const float pi = 3.1415927f;

class Vertex
{
public:
    Vertex(float px, float py, float pz, float nx, float ny, float nz, float u, float v)
    {
        // set vertex position, normal, and texture coordinates
        position[0] = px;
        position[1] = py;
        position[2] = pz;
        normal[0] = nx;
        normal[1] = ny;
        normal[2] = nz;
        texcoord[0] = u;
        texcoord[1] = v;
    }

private:
    vec3 position;
    vec3 normal;
    vec2 texcoord;
};

class Object
{
public:
    Object()
    {
        vertex_array = 0;
        vertex_buffer = 0;
        num_vertices = 0;
    }

    void create(std::vector<Vertex>& vertices, Shaders& shaders)
    {
        // create a vertex array object
        glGenVertexArrays(1, &vertex_array);
        glBindVertexArray(vertex_array);

        // create a vertex buffer object
        glGenBuffers(1, &vertex_buffer);
        glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
        glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(vertices[0]), vertices.data(), GL_STATIC_DRAW);

        // enable vertex positions
        GLint position_location = shaders.attrib("vertex_pos");
        glEnableVertexAttribArray(position_location);
        glVertexAttribPointer(position_location, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]), (void*) 0);

        // enable vertex normals
        GLint normal_location = shaders.attrib("vertex_normal");
        glEnableVertexAttribArray(normal_location);
        glVertexAttribPointer(normal_location, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]), (void*) (sizeof(float) * 3));

        // enable vertex texture coordinates
        GLint texcoord_location = shaders.attrib("vertex_texcoord");
        glEnableVertexAttribArray(texcoord_location);
        glVertexAttribPointer(texcoord_location, 2, GL_FLOAT, GL_FALSE, sizeof(vertices[0]), (void*) (sizeof(float) * 6));

        // store the number of vertices
        num_vertices = vertices.size();
    }

    void create_plane(Shaders& shaders)
    {
        std::vector<Vertex> vertices;

        // horizontal square: 6 vertices for 2 triangles
        vertices.push_back(Vertex(-1, 0, +1,  0, +1,  0, 0, 0));
        vertices.push_back(Vertex(+1, 0, +1,  0, +1,  0, 1, 0));
        vertices.push_back(Vertex(+1, 0, -1,  0, +1,  0, 1, 1));
        vertices.push_back(Vertex(-1, 0, +1,  0, +1,  0, 0, 0));
        vertices.push_back(Vertex(+1, 0, -1,  0, +1,  0, 1, 1));
        vertices.push_back(Vertex(-1, 0, -1,  0, +1,  0, 0, 1));

        create(vertices, shaders);
    }

    void create_cube(Shaders& shaders)
    {
        std::vector<Vertex> vertices;

        // front side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(-1, -1, +1,  0,  0, +1, 0, 0));
        vertices.push_back(Vertex(+1, -1, +1,  0,  0, +1, 1, 0));
        vertices.push_back(Vertex(+1, +1, +1,  0,  0, +1, 1, 1));
        vertices.push_back(Vertex(-1, -1, +1,  0,  0, +1, 0, 0));
        vertices.push_back(Vertex(+1, +1, +1,  0,  0, +1, 1, 1));
        vertices.push_back(Vertex(-1, +1, +1,  0,  0, +1, 0, 1));

        // back side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(+1, -1, -1,  0,  0, -1, 0, 0));
        vertices.push_back(Vertex(-1, -1, -1,  0,  0, -1, 1, 0));
        vertices.push_back(Vertex(-1, +1, -1,  0,  0, -1, 1, 1));
        vertices.push_back(Vertex(+1, -1, -1,  0,  0, -1, 0, 0));
        vertices.push_back(Vertex(-1, +1, -1,  0,  0, -1, 1, 1));
        vertices.push_back(Vertex(+1, +1, -1,  0,  0, -1, 0, 1));

        // left side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(-1, -1, -1, -1,  0,  0, 0, 0));
        vertices.push_back(Vertex(-1, -1, +1, -1,  0,  0, 1, 0));
        vertices.push_back(Vertex(-1, +1, +1, -1,  0,  0, 1, 1));
        vertices.push_back(Vertex(-1, -1, -1, -1,  0,  0, 0, 0));
        vertices.push_back(Vertex(-1, +1, +1, -1,  0,  0, 1, 1));
        vertices.push_back(Vertex(-1, +1, -1, -1,  0,  0, 0, 1));

        // right side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(+1, -1, +1, +1,  0,  0, 0, 0));
        vertices.push_back(Vertex(+1, -1, -1, +1,  0,  0, 1, 0));
        vertices.push_back(Vertex(+1, +1, -1, +1,  0,  0, 1, 1));
        vertices.push_back(Vertex(+1, -1, +1, +1,  0,  0, 0, 0));
        vertices.push_back(Vertex(+1, +1, -1, +1,  0,  0, 1, 1));
        vertices.push_back(Vertex(+1, +1, +1, +1,  0,  0, 0, 1));

        // bottom side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(-1, -1, -1,  0, -1,  0, 0, 0));
        vertices.push_back(Vertex(+1, -1, -1,  0, -1,  0, 1, 0));
        vertices.push_back(Vertex(+1, -1, +1,  0, -1,  0, 1, 1));
        vertices.push_back(Vertex(-1, -1, -1,  0, -1,  0, 0, 0));
        vertices.push_back(Vertex(+1, -1, +1,  0, -1,  0, 1, 1));
        vertices.push_back(Vertex(-1, -1, +1,  0, -1,  0, 0, 1));

        // top side: 6 vertices for 2 triangles
        vertices.push_back(Vertex(-1, +1, +1,  0, +1,  0, 0, 0));
        vertices.push_back(Vertex(+1, +1, +1,  0, +1,  0, 1, 0));
        vertices.push_back(Vertex(+1, +1, -1,  0, +1,  0, 1, 1));
        vertices.push_back(Vertex(-1, +1, +1,  0, +1,  0, 0, 0));
        vertices.push_back(Vertex(+1, +1, -1,  0, +1,  0, 1, 1));
        vertices.push_back(Vertex(-1, +1, -1,  0, +1,  0, 0, 1));

        create(vertices, shaders);
    }

    void create_cylinder(Shaders& shaders)
    {
        std::vector<Vertex> vertices;

        // subdivide the cylinder
        int n = 30;
        for (int i = 0; i < n; i++)
        {
            // current and next texture coordinates
            float u0 = float(i) / n;
            float u1 = float(i + 1) / n;

            // current and next positions
            float x0 = sinf(u0 * 2 * pi);
            float z0 = cosf(u0 * 2 * pi);
            float x1 = sinf(u1* 2 * pi);
            float z1 = cosf(u1* 2 * pi);

            // vertical side: 6 vertices for 2 triangles
            vertices.push_back(Vertex(x0, 0, z0, x0, 0, z0, u0, 0));
            vertices.push_back(Vertex(x1, 0, z1, x1, 0, z1, u1, 0));
            vertices.push_back(Vertex(x1, 1, z1, x1, 0, z1, u1, 1));
            vertices.push_back(Vertex(x0, 0, z0, x0, 0, z0, u0, 0));
            vertices.push_back(Vertex(x1, 1, z1, x1, 0, z1, u1, 1));
            vertices.push_back(Vertex(x0, 1, z0, x0, 0, z0, u0, 1));
        }

        create(vertices, shaders);
    }

    void create_torus(Shaders& shaders)
    {
        std::vector<Vertex> vertices;
        float r = 0.7f; // inner radius

        // subdivide the torus
        int n = 20;
        for (int i = 0; i < n; i++)
        {
            // current and next texture coordinates
            float u0 = float(i) / n;
            float u1 = float(i + 1) / n;

            // current and next positions
            float x0 = sinf(u0 * 2 * pi);
            float z0 = cosf(u0 * 2 * pi);
            float x1 = sinf(u1* 2 * pi);
            float z1 = cosf(u1* 2 * pi);

            // outer side: 6 vertices for 2 triangles
            vertices.push_back(Vertex(x0 * 1, 0, z0 * 1,  x0, 0, z0, u0, 0));
            vertices.push_back(Vertex(x1 * 1, 0, z1 * 1,  x1, 0, z1, u1, 0));
            vertices.push_back(Vertex(x1 * 1, 1, z1 * 1,  x1, 0, z1, u1, 1));
            vertices.push_back(Vertex(x0 * 1, 0, z0 * 1,  x0, 0, z0, u0, 0));
            vertices.push_back(Vertex(x1 * 1, 1, z1 * 1,  x1, 0, z1, u1, 1));
            vertices.push_back(Vertex(x0 * 1, 1, z0 * 1,  x0, 0, z0, u0, 1));

            // top side: 6 vertices for 2 triangles
            vertices.push_back(Vertex(x0 * 1, 1, z0 * 1,   0, +1, 0, u0, 0));
            vertices.push_back(Vertex(x1 * 1, 1, z1 * 1,   0, +1, 0, u1, 0));
            vertices.push_back(Vertex(x1 * r, 1, z1 * r,   0, +1, 0, u1, 1));
            vertices.push_back(Vertex(x0 * 1, 1, z0 * 1,   0, +1, 0, u0, 0));
            vertices.push_back(Vertex(x1 * r, 1, z1 * r,   0, +1, 0, u1, 1));
            vertices.push_back(Vertex(x0 * r, 1, z0 * r,   0, +1, 0, u0, 1));

            // inner side: 6 vertices for 2 triangles
            vertices.push_back(Vertex(x0 * r, 1, z0 * r, -x0, 0, -z0, u0, 0));
            vertices.push_back(Vertex(x1 * r, 1, z1 * r, -x1, 0, -z1, u1, 0));
            vertices.push_back(Vertex(x1 * r, 0, z1 * r, -x1, 0, -z1, u1, 1));
            vertices.push_back(Vertex(x0 * r, 1, z0 * r, -x0, 0, -z0, u0, 0));
            vertices.push_back(Vertex(x1 * r, 0, z1 * r, -x1, 0, -z1, u1, 1));
            vertices.push_back(Vertex(x0 * r, 0, z0 * r, -x0, 0, -z0, u0, 1));

            // bottom side: 6 vertices for 2 triangles
            vertices.push_back(Vertex(x0 * r, 0, z0 * r,   0, -1, 0, u0, 0));
            vertices.push_back(Vertex(x1 * r, 0, z1 * r,   0, -1, 0, u1, 0));
            vertices.push_back(Vertex(x1 * 1, 0, z1 * 1,   0, -1, 0, u1, 1));
            vertices.push_back(Vertex(x0 * r, 0, z0 * r,   0, -1, 0, u0, 0));
            vertices.push_back(Vertex(x1 * 1, 0, z1 * 1,   0, -1, 0, u1, 1));
            vertices.push_back(Vertex(x0 * 1, 0, z0 * 1,   0, -1, 0, u0, 1));
        }

        create(vertices, shaders);
    }

    void draw(Shaders& shaders, float px, float py, float pz, float sx, float sy, float sz)
    {
        // set the model matrix using object position and size
        mat4x4 model_matrix;
        mat4x4_identity(model_matrix);
        mat4x4_translate(model_matrix, px, py, pz);
        mat4x4_scale_aniso(model_matrix, model_matrix, sx, sy, sz);
        glUniformMatrix4fv(shaders.uniform("model_matrix"), 1, GL_FALSE, (const GLfloat*)model_matrix);

        // use the texture unit 0
        glUniform1i(shaders.uniform("sampler"), 0);

        // draw the triangles
        glBindVertexArray(vertex_array);
        glDrawArrays(GL_TRIANGLES, 0, num_vertices);
        glBindVertexArray(0);
    }

private:
    GLuint vertex_array;  // vertex array object
    GLuint vertex_buffer; // vertex buffer object
    int num_vertices;     // number of vertices
};
